
import React from 'react';
import { Pool, PoolStatus } from '../types';
import { COLORS } from '../constants';

interface PoolCardProps {
  pool: Pool;
  onClick: (id: string) => void;
  onContribute: (id: string) => void;
}

const PoolCard: React.FC<PoolCardProps> = ({ pool, onClick, onContribute }) => {
  const getStatusColor = (status: PoolStatus) => {
    switch (status) {
      case PoolStatus.HEALTHY: return 'bg-green-100 text-green-800 border-green-200';
      case PoolStatus.WARNING: return 'bg-amber-100 text-amber-800 border-amber-200';
      case PoolStatus.CRITICAL: return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow group">
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center text-slate-400 group-hover:bg-slate-200 transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusColor(pool.status)}`}>
            {pool.status}
          </span>
        </div>
        
        <h3 className="text-lg font-bold text-slate-900 mb-1">{pool.name}</h3>
        <p className="text-sm text-slate-500 capitalize mb-4">{pool.type} Cycle</p>

        <div className="space-y-3 mb-6">
          <div className="flex justify-between text-sm">
            <span className="text-slate-500">Contribution Amount:</span>
            <span className="font-semibold text-slate-900">R {pool.contributionAmount.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-500">Next Due Date:</span>
            <span className="font-semibold text-slate-900">{pool.nextDueDate}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-500">Rotation Position:</span>
            <span className="font-semibold text-slate-900">{pool.rotationPosition} of {pool.totalMembers}</span>
          </div>
        </div>

        <div className="flex gap-2">
          <button 
            onClick={() => onContribute(pool.id)}
            className="flex-grow bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg text-sm font-semibold transition-colors flex items-center justify-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Contribute
          </button>
          <button 
            onClick={() => onClick(pool.id)}
            className="p-2.5 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PoolCard;
