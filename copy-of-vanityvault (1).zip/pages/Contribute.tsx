
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_POOLS } from '../constants';

const Contribute: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const pool = MOCK_POOLS.find(p => p.id === id);
  const [paymentMethod, setPaymentMethod] = useState<'Bank' | 'Mobile' | 'Cash'>('Bank');
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!pool) return <div className="p-8 text-center">Pool not found</div>;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsUploading(true);
    setTimeout(() => setIsUploading(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => navigate('/dashboard'), 3000);
  };

  if (isSubmitted) {
    return (
      <div className="max-w-md mx-auto py-12 text-center animate-in zoom-in duration-300">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Payment Submitted!</h2>
        <p className="text-slate-500 mb-8">Your contribution proof has been sent for admin verification. You will receive a notification once approved.</p>
        <button onClick={() => navigate('/dashboard')} className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold">
          Return to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Submit Contribution Payment</h1>
          <p className="text-slate-500 text-sm">Upload your payment proof and submit for admin verification</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <h2 className="font-bold text-slate-900">{pool.name}</h2>
        <div className="flex justify-between items-center p-4 bg-slate-50 rounded-lg">
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Base Contribution</p>
            <p className="text-sm text-slate-400">Due: {pool.nextDueDate}</p>
          </div>
          <p className="text-xl font-bold text-slate-900">R {pool.contributionAmount.toLocaleString()}</p>
        </div>
        <div className="flex justify-between items-center px-4 pt-2">
          <p className="text-lg font-bold text-slate-900">Total Amount Due</p>
          <p className="text-xl font-bold text-green-600">R {pool.contributionAmount.toLocaleString()}</p>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-slate-900">Select Payment Method</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { id: 'Bank', name: 'Bank Transfer', icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4' },
            { id: 'Mobile', name: 'Mobile Money', icon: 'M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z' },
            { id: 'Cash', name: 'Cash Deposit', icon: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z' }
          ].map((method) => (
            <button
              key={method.id}
              onClick={() => setPaymentMethod(method.id as any)}
              className={`p-4 rounded-xl border flex flex-col items-center gap-2 transition-all ${
                paymentMethod === method.id ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-slate-200 hover:border-slate-300 text-slate-500'
              }`}
            >
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={method.icon} />
              </svg>
              <span className="text-sm font-semibold">{method.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-slate-900">Upload Payment Proof</h3>
        <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 flex flex-col items-center justify-center gap-4 bg-white relative">
          <input 
            type="file" 
            className="absolute inset-0 opacity-0 cursor-pointer" 
            onChange={handleFileUpload}
            accept="image/*,.pdf"
          />
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
          </div>
          <div className="text-center">
            <p className="text-sm font-bold text-slate-900">{isUploading ? 'Uploading...' : 'Drop your file here, or browse'}</p>
            <p className="text-xs text-slate-500">Supports: JPG, PNG, PDF (Max 5MB)</p>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
        <div className="flex gap-3">
          <svg className="w-5 h-5 text-blue-600 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <div className="space-y-1">
            <p className="text-sm font-bold text-blue-900">Proof Requirements:</p>
            <ul className="text-xs text-blue-700 list-disc pl-4 space-y-1">
              <li>Clear and readable transaction details</li>
              <li>Visible amount matching contribution due</li>
              <li>Transaction date and reference number</li>
              <li>Recipient account information (if applicable)</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-bold text-slate-900">Additional Notes (Optional)</label>
        <textarea 
          placeholder="Add any additional information about this payment..." 
          className="w-full p-4 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all min-h-[100px]"
        />
      </div>

      <div className="flex gap-4 pt-4 sticky bottom-4 bg-slate-50/80 backdrop-blur pb-4">
        <button onClick={() => navigate(-1)} className="flex-grow bg-white border border-slate-200 text-slate-700 py-4 rounded-xl font-bold hover:bg-slate-50 transition-colors">
          Save Draft
        </button>
        <button onClick={handleSubmit} className="flex-[2] bg-green-600 hover:bg-green-700 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-green-600/20 transition-all">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          Submit Payment
        </button>
      </div>
    </div>
  );
};

export default Contribute;
